package com.example.businesscardapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.businesscardapp.ui.theme.BusinessCardAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BusinessCardAppTheme {
                CartaDePresentacionApp(
                        Telefono = "+34 666 999 666",
                        RedesSociales = "@github.com/nacho_espadas_2023",
                        CorreoElectronico = "nacho.espadas@gmail.com",
                        Nombre = "Nacho Espadas",
                        Designacion = "Desarrollador Kotlin Android",
                        android = "android"
                )
            }
        }
    }
}

@Composable
fun CartaDePresentacionApp(
    Telefono: String,
    RedesSociales: String,
    CorreoElectronico: String,
    Nombre: String,
    Designacion: String,
    android: String
) {
    val raleway1 = FontFamily(Font(R.font.raleway2))
    val poppins = FontFamily(Font(R.font.poppins))
    val image = painterResource(R.drawable.nature_zima_noch_gori_doroga_planeti_fantasticheskii_peizazh_112101)
    Box {
        Image(
            painter = image,
            contentDescription = null,
            contentScale = ContentScale.Crop
        )
}
    Column(
        modifier = Modifier.padding(bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    )
    {
        val androidImagen = painterResource(id = R.drawable.android_logo)
        Box {
            Image(
                painter = androidImagen,
                contentDescription = null,
                modifier = Modifier.padding(top = 35.dp)
            )
            Column(
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(start = 30.dp, bottom = 40.dp), 
                ) {
                Spacer(modifier = Modifier.weight(1f))
                val callImage = painterResource(id = R.drawable.call_48px)
                val shareImage = painterResource(id = R.drawable.share_48px)
                val emailImage = painterResource(id = R.drawable.mail_48px)
                Row(
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {

                    Image(
                        painter = callImage,
                        contentDescription = null
                    )
                    Text(
                        text = Telefono,
                        color = Color.Black,
                        modifier = Modifier.padding(start = 30.dp, top = 3.dp)
                    )
                }
                Row(
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {
                    Image(
                        painter = shareImage,
                        contentDescription = null
                    )
                    Text(
                        text = RedesSociales,
                        color = Color.Black,
                        modifier = Modifier.padding(start = 30.dp, top = 3.dp)
                    )
                }
                Row(
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {
                    Image(
                        painter = emailImage,
                        contentDescription = null
                    )
                    Text(
                        text = CorreoElectronico,
                        color = Color.Black,
                        modifier = Modifier.padding(start = 30.dp, top = 3.dp)
                    )
                    Text(
                        text = android,
                        fontFamily = poppins,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(top = 100.dp, start = 20.dp)
                    )
            }
        }
        Text(
            text = Nombre,
            fontSize = 55.sp,
            color = Color.Blue,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 430.dp, bottom = 3.dp),
            fontFamily = raleway1)
        Text(
            text = Designacion,
            fontSize = 26.sp,
            modifier = Modifier.padding(top = 510.dp, start = 5.dp),
            color = Color(0xFFCE3939))

        }
    }
}


@Preview(showBackground = true)
@Composable
fun VistaPrevia() {
    BusinessCardAppTheme {
        Surface {
            CartaDePresentacionApp(
                Telefono = "+34 666 999 666",
                RedesSociales = "@github.com/nacho_espadas_2023",
                CorreoElectronico = "nacho.espadas@gmail.com",
                Nombre = "Nacho Espadas",
                Designacion = "Desarrollador Kotlin Android",
                android = "android"
            )
        }
    }
}